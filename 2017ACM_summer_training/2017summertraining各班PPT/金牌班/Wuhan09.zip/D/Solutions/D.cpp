#include <cstdio>
#include <cstring>

int main()
{

    int     cnt_case = 0;
    int     T, n, B;
    double  S, P;
    while (scanf("%d%d%d", &T, &n, &B) > 0 && T)
    {
        double  tot = 0;
        while (T--)
        {
            scanf("%lf%lf", &S, &P);
            tot += S * (100 - P) / 100.0;            
        }
        printf("Case %d: %.2lf\n\n", ++ cnt_case, tot / B);
    }

    return 0;
}
