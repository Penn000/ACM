#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <ctime>

const int       LIMIT_V1 = 500 + 10;
const int       LIMIT_V2 = 50  + 10;
const int       LIMIT_N  = 300 + 10;

struct Gift
{
    int     price, happiness, is_special;
};

int     V1, V2, n;
Gift    list[LIMIT_N];

void init()
{
    for (int i = 0; i < n; i ++)
        scanf("%d%d%d", &list[i].price, &list[i].happiness, &list[i].is_special);
}

int     opt[2][LIMIT_V1][LIMIT_V2][2];

inline void renew(int& x, int x0)
{
    if (x0 > x) x = x0;
}

void solve()
{
    int     i, a, b;
    int     sp = 0;
    int     prev = 0, next;

    memset(opt[prev], 0xff, sizeof(opt[prev]));    
    opt[prev][0][0][0] = 0;

    for (i = 0; i < n; i ++)
    {
        next = 1 - prev;
        memset(opt[next], 0xff, sizeof(opt[next]));

        for (a = 0; a <= sp && a <= V1; a ++)
            for (b = 0; b <= sp && b <= V2; b ++)
            {
                if (opt[prev][a][b][0] >= 0)
                {
                    // do not buy
                    if (! list[i].is_special)
                        renew(opt[next][a][b][0], opt[prev][a][b][0]);
                    // buy it
                    if (a + list[i].price <= V1)
                        renew(opt[next][a + list[i].price][b][0], opt[prev][a][b][0] + list[i].happiness);
                    if (b + list[i].price <= V2)
                        renew(opt[next][a][b + list[i].price][0], opt[prev][a][b][0] + list[i].happiness);
                    renew(opt[next][a][b][1], opt[prev][a][b][0] + list[i].happiness);
                }
                if (opt[prev][a][b][1] >= 0)
                {
                    if (! list[i].is_special)
                        renew(opt[next][a][b][1], opt[prev][a][b][1]);
                    // buy it
                    if (a + list[i].price <= V1)
                        renew(opt[next][a + list[i].price][b][1], opt[prev][a][b][1] + list[i].happiness);
                    if (b + list[i].price <= V2)
                        renew(opt[next][a][b + list[i].price][1], opt[prev][a][b][1] + list[i].happiness);
                }
            }

        sp += list[i].price;
        prev = next;
    }

    int ret = -1;
    for (a = 0; a <= sp && a <= V1; a ++)
        for (b = 0; b <= sp && b <= V2; b ++)
        {
            if (opt[prev][a][b][0] >= 0)
                renew(ret, opt[prev][a][b][0]);
            if (opt[prev][a][b][1] >= 0)
                renew(ret, opt[prev][a][b][1]);
        }

    printf("%d\n\n", ret);
}

int main()
{
    int case_no = 0;
    while (scanf("%d%d%d", &V1, &V2, &n) > 0 && n)
    {
        printf("Case %d: ", ++ case_no);

        init();
        solve();
    }

    fprintf(stderr, "twb runtime : %.3lfs\n", clock() / (double)CLK_TCK);

    return 0;
}
