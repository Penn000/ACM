#include <cstdio>
#include <algorithm>
#include <cmath>
#include <vector>
#include <cstring>
#include <string>
#include <ctime>
#include <cassert>
using namespace std;

const double eps = 1e-10;
const double pi = acos(-1.0);

const int dx[4] = {
    1, 0, -1, 0
};

const int dy[4] = {
    0, -1, 0, 1
};

int dcmp(double x) {
    return (x > +eps) - (x < -eps);
}

struct point {
    double x, y;
    point() {}
    point(double _x, double _y) : x(_x), y(_y) {}
    point operator + (const point& p) const {
        return point(x + p.x, y + p.y);
    }
    point operator - (const point& p) const {
        return point(x - p.x, y - p.y);
    }
    point operator * (double p) const {
        return point(x * p, y * p);
    }
    point operator / (double p) const {
        return point(x / p, y / p);
    }
    point trun_left() const {
        return point(-y, x);
    }
    point trun_right() const {
        return point(y, -x);
    }
    point rotate(double a) const {
        return point(x * cos(a) - y * sin(a), x * sin(a) + y * cos(a));
    }
    point trunc(double len) const {
        return *this * len / sqrt(x * x + y * y);
    }
    bool operator < (const point& p) const {
        return dcmp(x - p.x) < 0 || (dcmp(x - p.x) == 0 && dcmp(y - p.y) < 0);
    }
    bool operator ==(const point& p) const {
        return dcmp(x - p.x) == 0 && dcmp(y - p.y) == 0;
    }
    bool operator !=(const point& p) const {
        return dcmp(x - p.x) != 0 || dcmp(y - p.y) != 0;
    }
    double len() {
        return sqrt(x * x + y * y);
    }
};

double xmul(const point& a, const point& b) {
    return a.x * b.y - a.y * b.x;
}

double xmul(const point& a, const point& b, const point& c) {
    return xmul(b - a, c - a);
}

double dmul(const point& a, const point& b) {
    return a.x * b.x + a.y * b.y;
}

double dmul(const point& a, const point& b, const point& c) {
    return dmul(b - a, c - a);
}

double dist(const point& a, const point& b) {
    return sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y));
}

struct Circle {
    double x, y, r;
    Circle() {}
    Circle(double _x, double _y, double _r) : x(_x), y(_y), r(_r) {}
    bool operator ==(const Circle& c) const {
        return dcmp(x - c.x) == 0 && dcmp(y - c.y) == 0 && dcmp(r - c.r) == 0;
    }
    bool inside(const point& p) const {
        return dcmp((x - p.x) * (x - p.x) + (y - p.y) * (y - p.y) - r * r) <= 0;
    }
};

struct cmp {
    point c;
    cmp() {}
    cmp(const point& c) : c(c) {}
    bool operator () (const point& a, const point& b) {
        return dcmp(atan2(a.y - c.y, a.x - c.x) - atan2(b.y - c.y, b.x - c.x)) < 0;
    }
};

bool circle_intersection(const Circle& s, const Circle& t, point& a, point& b) {
    double dd = dist(point(s.x, s.y), point(t.x, t.y));
    if (dcmp(dd - (s.r + t.r)) > 0) {
        return false;
    }
    if (dcmp(dd - fabs(s.r - t.r)) < 0) {
        return false;
    }
    double x1 = (dd * dd + s.r * s.r - t.r * t.r) / dd / 2;
    double y1 = sqrt(s.r * s.r - x1 * x1);
    point cs = point(s.x, s.y), ct = point(t.x, t.y);
    point mid = cs + (ct - cs).trunc(x1);
    a = mid + ((ct - cs).trun_left()).trunc(y1);
    b = mid + ((ct - cs).trun_right()).trunc(y1);
    return true;
}

double arc_area(const point& a, const point& b, const point& c, double r) {
    double d = dist(a, b);
    double alpha = 2 * asin(d / r / 2);
    return (alpha - sin(alpha)) * r * r / 2;
}

bool union_check(const point& p, const vector<Circle>& cir) {
    for (int i = 0; i < cir.size(); ++i) {
        if (dcmp(dist(p, point(cir[i].x, cir[i].y)) - cir[i].r) < 0) {
            return false;
        }
    }
    return true;
}

double union_area(const vector<Circle>& in) {
    vector<Circle> cir;
    for (int i = 0; i < in.size(); ++i) {
        if (dcmp(in[i].r) == 0) {
            continue;
        }
        bool flag = true;
        for (int j = i + 1; flag && j < in.size(); ++j) {
            if (dcmp(in[i].x - in[j].x) == 0 && dcmp(in[i].y - in[j].y) == 0 && dcmp(in[i].r - in[j].r) == 0) {
                flag = false;
            }
        }
        if (!flag) {
            continue;
        }
        for (int j = 0; flag && j < in.size(); ++j) {
            if (i != j) {
                double dd = dist(point(in[i].x, in[i].y), point(in[j].x, in[j].y));
                if (dcmp(dd + in[i].r - in[j].r) < 0) {
                    flag = false;
                }
            }
        }
        if (!flag) {
            continue;
        }
        cir.push_back(in[i]);
    }
    vector<vector<point> > on_point(cir.size());
    for (int i = 0; i < cir.size(); ++i) {
        for (int j = 0; j < 4; ++j) {
            on_point[i].push_back(point(cir[i].x, cir[i].y) + point(dx[j], dy[j]) * cir[i].r);
        }
    }
    for (int i = 0; i < cir.size(); ++i) {
        for (int j = i + 1; j < cir.size(); ++j) {
            point a, b;
            if (circle_intersection(cir[i], cir[j], a, b)) {
                on_point[i].push_back(a), on_point[i].push_back(b);
                on_point[j].push_back(b), on_point[j].push_back(a);
            }
        }
    }
    double ans = 0.0;
    for (int i = 0; i < cir.size(); ++i) {
        point c = point(cir[i].x, cir[i].y);
        sort(on_point[i].begin(), on_point[i].end(), cmp(c));
        on_point[i].erase(unique(on_point[i].begin(), on_point[i].end()), on_point[i].end());
        for (int j = 0; j < on_point[i].size(); ++j) {
            int k = (j + 1) % on_point[i].size();
            point a = on_point[i][j], b = on_point[i][k];
            point mid = c + (b - a).trun_right().trunc(cir[i].r);
            if (union_check(mid, cir)) {
                ans += arc_area(a, b, c, cir[i].r);
                ans += xmul(a, b) / 2.0;
            }
        }
    }
    return ans;
}

bool inter_check(const point& p, const vector<Circle>& cir) {
    int cnt = 0;
    for (int i = 0; i < cir.size(); ++i) {
        if (dcmp(dist(p, point(cir[i].x, cir[i].y)) - cir[i].r) <= 0) {
            ++cnt;
        }
    }
    if (cnt == cir.size()) return true;
    return false;
}

double inter_area(const vector<Circle>& in) {
    vector<Circle> cir;
    for (int i = 0; i < in.size(); ++i) {
        bool flag = true;
        for (int j = 0; flag && j < cir.size(); ++j) {
            if (in[i] == cir[j]) {
                flag = false;
            }
        }
        if (!flag) {
            continue;
        }
        cir.push_back(in[i]);
    }
    vector<vector<point> > on_point(cir.size());
    for (int i = 0; i < cir.size(); ++i) {
        for (int j = 0; j < 4; ++j) {
            on_point[i].push_back(point(cir[i].x, cir[i].y) + point(dx[j], dy[j]) * cir[i].r);
        }
    }
    for (int i = 0; i < cir.size(); ++i) {
        for (int j = i + 1; j < cir.size(); ++j) {
            point a, b;
            if (circle_intersection(cir[i], cir[j], a, b)) {
                on_point[i].push_back(a), on_point[i].push_back(b);
                on_point[j].push_back(b), on_point[j].push_back(a);
            }
        }
    }
    double ans = 0.0;
    for (int i = 0; i < cir.size(); ++i) {
        point c = point(cir[i].x, cir[i].y);
        sort(on_point[i].begin(), on_point[i].end(), cmp(c));
        on_point[i].erase(unique(on_point[i].begin(), on_point[i].end()), on_point[i].end());
        for (int j = 0; j < on_point[i].size(); ++j) {
            int k = (j + 1) % on_point[i].size();
            point a = on_point[i][j], b = on_point[i][k];
            point mid = c + (b - a).trun_right().trunc(cir[i].r);
            if (inter_check(mid, cir)) {
                ans += arc_area(a, b, c, cir[i].r);
                ans += xmul(a, b) / 2.0;
            }
        }
    }
    return ans;
}

double RandDouble(double a, double b) {
    return a + static_cast<double>(rand()) / RAND_MAX * (b - a);
}

bool inside_circle(double x, double y, double cx, double cy, double rr) {
    double tmp = (x - cx) * (x - cx) + (y - cy) * (y - cy);
    return dcmp(tmp - rr * rr) <= 0;
}

vector<Circle> in;

double random() {
    srand((int)time(0));
    double minx = in[0].x - in[0].r, miny = in[0].y - in[0].r, maxx = in[0].x + in[0].r, maxy = in[0].y + in[0].r;
    for (int i = 1; i < in.size(); ++i) {
        minx = min(minx, in[i].x - in[i].r);
        miny = min(miny, in[i].y - in[i].r);
        maxx = max(maxx, in[i].x + in[i].r);
        maxy = max(maxy, in[i].y + in[i].r);
    }
    int cnt = 0, total = 1000000;
    for (int i = 0; i < total; ++i) {
        double x = RandDouble(minx, maxx), y = RandDouble(miny, maxy);
        int pp = 0;
        for (int j = 0; j < in.size(); ++j) {
            if (inside_circle(x, y, in[j].x, in[j].y, in[j].r)) {
                ++pp;
            }
        }
        if (pp >= 1 && pp <= 3) {
            ++cnt;
        }
    }
    return 1.0 * (maxx - minx) * (maxy - miny) * cnt / total;
}

int main() {
    point s, t, a, b;
    int ca = 1;
    while (scanf("%lf %lf %lf %lf", &s.x, &s.y, &t.x, &t.y) != EOF) {
        scanf("%lf %lf %lf %lf", &a.x, &a.y, &b.x, &b.y);
        if (fabs(s.x) < eps && fabs(s.y) < eps && fabs(t.x) < eps && fabs(t.y) < eps && fabs(a.x) < eps && fabs(a.y) < eps && fabs(b.x) < eps && fabs(b.y) < eps) {
            break;
        }
        in.clear();
        in.resize(4);
        double r1 = (s - a).len() / 2;
        double r2 = (s - b).len() / 2;
        double r3 = (t - a).len() / 2;
        double r4 = (t - b).len() / 2;
        in[0] = Circle((s.x + a.x) / 2, (s.y + a.y) / 2, r1);
        in[1] = Circle((s.x + b.x) / 2, (s.y + b.y) / 2, r2);
        in[2] = Circle((t.x + a.x) / 2, (t.y + a.y) / 2, r3);
        in[3] = Circle((t.x + b.x) / 2, (t.y + b.y) / 2, r4);
        double ans1 = union_area(in);
        double ans2 = inter_area(in);
        printf("Case %d: %.3lf\n", ca++, fabs(ans1 - ans2));// ��ֹ-0.000
        printf("\n");
    }
    return 0;
}
