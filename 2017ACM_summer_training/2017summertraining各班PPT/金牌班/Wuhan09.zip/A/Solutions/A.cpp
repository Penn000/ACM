#include<iostream>
#include<vector>
#include<queue>
#include<sstream>
using namespace std;

const int MAXN = 500 + 10;
const int MAXM = 500 + 10;
const int MAXT = 500 * 100 + 10;

int n, m, o, sumT;
int T[MAXN], I[MAXN], O[MAXN], in[MAXN][10], out[MAXN][10], deg[MAXN];
int st[MAXM];
queue<int> finish[MAXT];
vector<int> check[MAXM], sons[MAXN], root;

void go(int p, int t, int prev) {
	finish[t+T[p]].push(p);
	if(prev >= 0) sons[prev].push_back(p);
}

int simulate() {
	int s, p2;
	for(int t = 0; t <= sumT; t++) {
		while(!finish[t].empty()) {
			int p = finish[t].front();
			finish[t].pop();
			for(int i = 0; i < O[p]; i++) if(!st[s = out[p][i]]) {
				st[s] = 1;
				for(int j = 0; j < check[s].size(); j++)
					if(--deg[p2 = check[s][j]] == 0) go(p2, t, p);
			}
		}
		if(st[o]) return t;
	}
	return -1;
}

string doit(int p) {
	stringstream ss;
	int s = sons[p].size();
	ss << "P" << (p+1);
	if(!s) return ss.str();
	if(s == 1) ss << doit(sons[p][0]);
	else {
		ss << "(" << doit(sons[p][0]);
		for(int i = 1; i < s; i++) ss << "|" << doit(sons[p][i]);
		ss << ")";
	}
	return "(" + ss.str() + ")";
}

int main() {
	string s;
	int caseno = 0;
	while(cin >> n && n) {
		cin >> m >> o >> s;
		for(int i = 1; i <= m; i++) { check[i].clear(); st[i] = (s[i-1] == '1' ? 1 : 0); }
		sumT = 0;
		for(int i = 0; i < n; i++) {
			sons[i].clear();
			cin >> T[i] >> I[i];
			sumT += T[i]; deg[i] = I[i];
			for(int j = 0; j < I[i]; j++) { cin >> in[i][j]; check[in[i][j]].push_back(i); }
			cin >> O[i];
			for(int j = 0; j < O[i]; j++) cin >> out[i][j];
		}
		int p;
		root.clear();
		for(int i = 1; i <= m; i++) if (st[i]) {
			for(int j = 0; j < check[i].size(); j++)
				if(--deg[p = check[i][j]] == 0) { go(p, 0, -1); root.push_back(p); }
		}
		int ans = simulate();
		for(int i = 0; i <= sumT; i++) while(!finish[i].empty()) finish[i].pop();
		cout << "Case " << ++caseno << ": " << ans;

		if(ans >= 0) {
			s = doit(root[0]);
			for(int i = 1; i < root.size(); i++) s = s + "|" + doit(root[i]);
			cout << " " << (root.size() == 1 ? s : "(" + s + ")");
		}

		cout << endl << endl;
	}
	return 0;
}
