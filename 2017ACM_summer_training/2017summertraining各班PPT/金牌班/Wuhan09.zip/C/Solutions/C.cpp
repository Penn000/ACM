#include <cstdio>

int main()
{

    int     n;
    double  D;

    int     cnt_case = 0;

    while (scanf("%d%lf", &n, &D) > 0 && D > 0)
    {
        double      ans = 0;
        double      p, L, v;

        while (n --)
        {
            scanf("%lf%lf%lf", &p, &L, &v);
            ans += 2.0 * L / v;
            D -= L;
        }

        printf("Case %d: %.3lf\n\n", ++ cnt_case, D + ans);
    }

    return 0;
}
