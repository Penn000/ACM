#include <cstdio>
#include <vector>
#include <cstring>
#include <algorithm>
#include <queue>
using namespace std;
const int maxn = 1005 * 2;
char buf[100];
int n;
struct T{
    int v[maxn], deg[maxn];
    vector<int> vec[maxn];
    void clear(){
        for(int i = 1; i <= 2 * n; i ++){
            vec[i].clear();
        }
        memset(deg, 0, sizeof(deg));
        memset(v, -1, sizeof(v));
    }
    void insert(int t1, int t2){
        vec[t1].push_back(t2);
        deg[t2] ++;
    }
    bool process(){
        queue<int> que;
        for(int i = 1; i <= 2*n; i ++){
            if(deg[i] == 0){
                que.push(i);
                v[i] = 0;
            }
        }
        while(!que.empty()){
            int q = que.front(); que.pop();
            for(int i = 0; i < vec[q].size(); i ++){
                v[vec[q][i]] = max(v[vec[q][i]], v[q] + 1);
                deg[vec[q][i]] --;
                if(deg[vec[q][i]] == 0) que.push(vec[q][i]);
            }
        }
        for(int i = 1; i <= 2*n; i ++){
            if(deg[i] != 0) return false;
        }
        return true;
    }
}p[3];
int main(){
    int r, t1, t2, cas = 0;
    while(scanf("%d%d", &n, &r) > 0){
        if(n == 0 && r == 0) break;
        printf("Case %d: ", ++cas);
        for(int i = 0; i < 3; i ++){
            p[i].clear();
            for(int j = 1; j <= n; j ++){
                p[i].insert(j, j + n);
            }
        }
        for(int i = 0; i < r; i ++){
            scanf("%s%d%d", &buf, &t1, &t2);
            if(buf[0] == 'I'){
                p[0].insert(t2, t1 + n); p[0].insert(t1, t2 + n);
                p[1].insert(t2, t1 + n); p[1].insert(t1, t2 + n);
                p[2].insert(t2, t1 + n); p[2].insert(t1, t2 + n);
            }else if(buf[0] == 'X'){
                p[0].insert(t1+n, t2);
            }else if(buf[0] == 'Y'){
                p[1].insert(t1+n, t2);
            }else if(buf[0] == 'Z'){
                p[2].insert(t1+n, t2);
            }else while(1);
        }
        bool ok = true;
        for(int i = 0; i < 3; i ++){
            if(!p[i].process()){
                ok = false; break;
            }
        }
        if(!ok){
            printf("IMPOSSIBLE\n");
        }else{
            printf("POSSIBLE\n");
            for(int i = 1; i <= n; i ++){
                printf("%d %d %d %d %d %d\n", p[0].v[i], p[1].v[i], p[2].v[i], 
                        p[0].v[i+n], p[1].v[i+n], p[2].v[i+n]);
            }
        }
        printf("\n");
    }
}
