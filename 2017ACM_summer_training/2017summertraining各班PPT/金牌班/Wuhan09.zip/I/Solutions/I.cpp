/*
 * Author: momodi
 * Created Time:  2009/9/11 16:26:52
 * File Name: GCC.cpp
 * Description: 
 */
#include <cstdio>
#include <cstring>
#include <cmath>
#include <vector>
#include <cstdlib>
#include <algorithm>
#include <map>
#include <set>
#include <queue>
using namespace std;
#define out(x) fprintf(stderr, "%s: %I64d\n", #x, (long long)(x))
#define SZ(v) ((int)(v).size())
const int maxint=-1u>>1;
template <class T> bool get_max(T& a, const T &b) {return b > a? a = b, 1: 0;}
template <class T> bool get_min(T& a, const T &b) {return b < a? a = b, 1: 0;}
#define MOD(v) ((v) >= M ? (v) -= M: 1)
const int maxn = (1 << 17) - 1;
const int M = 19880830;
struct Adj {
    int v, c;
    Adj(int _v, int _c)
        :v(_v), c(_c) {}
    Adj() {}
};
vector<Adj> adj[maxn];
int distS[maxn], distT[maxn];
int cntS[maxn], cntT[maxn];
int preS[maxn], preT[maxn];
int n, m, S, T;
set<int> U, O, D;
int dist[maxn], cnt[maxn];
set<pair<int, int> > HD;
map<int, int> CD;
map<int, pair<int, int> > ans;
bool engaged[maxn];

void Dijkstra(int dist[], int cnt[], int pre[], int S) {
    pre[S] = -1;
    fill(dist, dist + n, maxint);
    dist[S] = 0;
    set<pair<int, int> > heap;
    heap.insert(make_pair(dist[S], S));
    cnt[S] = 1;
    while (!heap.empty()) {
        pair<int, int> v = *heap.begin();
        heap.erase(heap.begin());
        for (vector<Adj>::iterator it = adj[v.second].begin(); it != adj[v.second].end(); ++it) {
            if (v.first + it->c < dist[it->v]) {
                heap.erase(make_pair(dist[it->v], it->v));
                dist[it->v] = v.first + it->c;
                heap.insert(make_pair(dist[it->v], it->v));
                cnt[it->v] = cnt[v.second];
                pre[it->v] = v.second;
            } else if (v.first + it->c == dist[it->v]) {
                cnt[it->v] += cnt[v.second];
                MOD(cnt[it->v]);
            }
        }
    }
}

set<int> findSet(int now, int pro) {
    queue<int> Q;
    Q.push(now);
    set<int> ans;
    while (!Q.empty()) {
        int v = Q.front();
//        out(v);
        Q.pop();
        ans.insert(v);
        for (vector<Adj>::iterator it = adj[v].begin(); it != adj[v].end(); ++it) {
            if (it->v != pro && preS[it->v] == v) {
                Q.push(it->v);
            }
        }
    }
    return ans;
}

void updateHD(int now, int dd, int cc) {
    CD[dist[now]] += M - cnt[now];
    MOD(CD[dist[now]]);
    if (CD[dist[now]] == 0) {
        CD.erase(dist[now]);
    }
    HD.erase(make_pair(dist[now], now));
    dist[now] = dd;
    HD.insert(make_pair(dist[now], now));
    cnt[now] = cc;
    CD[dist[now]] += cnt[now];
    MOD(CD[dist[now]]);
}

void updateD(int now, int dd, int cc) {
    for (vector<Adj>::iterator it = adj[now].begin(); it != adj[now].end(); ++it) {
        if (D.count(it->v)) {
            if (dd + it->c + distT[it->v] < dist[it->v]) {
                updateHD(it->v, dd + it->c + distT[it->v], (long long)cc * cntT[it->v] % M);
            } else if (dd + it->c + distT[it->v] == dist[it->v] ) {
                int k = (long long)cc * cntT[it->v] % M;
                cnt[it->v] += k;
                MOD(cnt[now]);
                CD[dist[it->v]] += k;
                MOD(CD[dist[it->v]]);
            }
        }
    }
}

void removeO() {
    for (set<int>::iterator it = O.begin(); it != O.end(); ++it) {
        if (dist[*it] != maxint) {
            for (vector<Adj>::iterator jt = adj[*it].begin(); jt != adj[*it].end(); ++jt) {
                if (D.count(jt->v)) {
                    if (dist[*it] + jt->c + distT[jt->v] == dist[jt->v]) {
                        int k = (long long)cnt[*it] * cntT[jt->v] % M;
                        cnt[jt->v] += M - k;
                        MOD(cnt[jt->v]);
                        CD[dist[jt->v]] += M - k;
                        MOD(CD[dist[jt->v]]);
                        if (CD[dist[jt->v]] == 0) {
                            CD.erase(dist[jt->v]);
                        }
                    }
                }
            }
        }
    }
}

void init(const set<int> &in) {
    for (set<int>::const_iterator it = in.begin(); it != in.end(); ++it) {
        dist[*it] = maxint;
        for (vector<Adj>::iterator jt = adj[*it].begin(); jt != adj[*it].end(); ++jt) {
            if (U.count(jt->v)) {
                if (dist[jt->v] + jt->c < dist[*it]) {
                    dist[*it] = dist[jt->v] + jt->c;
                    cnt[*it] = cnt[jt->v];
                } else if (dist[jt->v] + jt->c == dist[*it]) {
                    cnt[*it] += cnt[jt->v];
                    MOD(cnt[*it]);
                }
            }
        }
    }
}

void update(const set<int> &in) {
    set<pair<int, int> > heap;
    for (set<int>::const_iterator it = in.begin(); it != in.end(); ++it) {
        if (dist[*it] != maxint) {
            heap.insert(make_pair(dist[*it], *it));
        }
    }
    while (!heap.empty()) {
        pair<int, int> v = *heap.begin();
        updateD(v.second, v.first, cnt[v.second]);
        heap.erase(heap.begin());
        for (vector<Adj>::iterator it = adj[v.second].begin(); it != adj[v.second].end(); ++it) {
            if (in.count(it->v)) {
                if (v.first + it->c < dist[it->v]) {
                    heap.erase(make_pair(dist[it->v], it->v));
                    dist[it->v] = v.first + it->c;
                    heap.insert(make_pair(dist[it->v], it->v));
                    cnt[it->v] = cnt[v.second];
                } else if (v.first + it->c == dist[it->v]) {
                    cnt[it->v] += cnt[v.second];
                    MOD(cnt[it->v]);
                }
            }
        }
    }
}

void engage(int now) {
    engaged[now] = true;
    queue<int> Q;
    Q.push(now);
    while (!Q.empty()) {
        int v = Q.front();
        Q.pop();
        for (vector<Adj>::iterator it = adj[v].begin(); it != adj[v].end(); ++it) {
            if (engaged[it->v] == false && distS[v] + it->c == distS[it->v]) {
                preS[it->v] = v;
                engaged[it->v] = true;
                Q.push(it->v);
            }
        }
    }
}

void build() {
    Dijkstra(distS, cntS, preS, S);
    Dijkstra(distT, cntT, preT, T);
    ans.clear();
    if (distS[T] == maxint || preS[T] == S) {
        return ;
    }
    vector<int> sta;
    int now = T;
    static int next[maxn];
    fill(engaged, engaged + n, false);
    while (now != S) {
        sta.push_back(now);
        next[preS[now]] = now;
        now = preS[now];
        engage(now);
    }
    U = findSet(S, next[S]);
    O = findSet(next[S], next[next[S]]);
    O.erase(next[S]);
    D = findSet(next[next[S]], -1);
    HD.clear();
    CD.clear();
    for (set<int>::iterator it = D.begin(); it != D.end(); ++it) {
        HD.insert(make_pair(dist[*it] = maxint, *it));
    }
    for (set<int>::iterator it = U.begin(); it != U.end(); ++it) {
        dist[*it] = maxint;
    }
    dist[S] = 0;
    cnt[S] = 1;
    update(U);
    init(O);
    update(O);
    while (true) {
        int v = sta.back();
        sta.pop_back();
        ans[v] = make_pair(HD.begin()->first, CD[HD.begin()->first]);
        int nv = next[v];
        if (nv == T) {
            break;
        }
        set<int> nextO = findSet(nv, next[nv]);
        for (set<int>::iterator it = nextO.begin(); it != nextO.end(); ++it) {
            D.erase(*it);
            HD.erase(make_pair(dist[*it], *it));
            CD[dist[*it]] += M - cnt[*it];
            MOD(CD[dist[*it]]);
            if (CD[dist[*it]] == 0) {
                CD.erase(dist[*it]);
            }
        }
        removeO();
        O.insert(v);
        init(O);
        update(O);
        for (set<int>::iterator it = O.begin(); it != O.end(); ++it) {
            U.insert(*it);
        }
        O = nextO;
        O.erase(nv);
        init(O);
        update(O);
    }
}

pair<int, int> solve(int v) {
    if (v == S || v == T) {
        return make_pair(maxint, 0);
    }
    if (ans.count(v)) {
        return ans[v];
    }
    if (distS[v] == maxint || distT[v] == maxint || distS[v] + distT[v] > distS[T]) {
        return make_pair(distS[T], cntS[T]);
    }
    int a = distS[T];
    int b = cntS[T];
    b += M - (long long)cntS[v] * cntT[v] % M;
    MOD(b);
    return make_pair(a, b);
}

int main() {
    int cc = 0;
    int Q;
    while (scanf("%d %d %d %d %d", &n, &m, &S, &T, &Q) == 5 && (n || m || S || T || Q)) {
        --S, --T;
        printf("Case %d:", ++cc);
        for (int i = 0; i < n; ++i) {
            adj[i].clear();
        }
        for (int i = 0; i < m; ++i) {
            int u, v, c;
            scanf("%d %d %d", &u, &v, &c);
            --u, --v;
            adj[u].push_back(Adj(v, c));
            adj[v].push_back(Adj(u, c));
        }
        build();
        while (Q--) {
            long long ans = 0;
            long long x = 1;
            int k;
            scanf("%d", &k);
            for (int i = 0; i < n; ++i) {
                pair<int, int> t = solve(i);
                if (t.first == maxint) {
                    t = make_pair(0, 0);
                }
                ans = (ans + t.first * x) % M;
                x = x * k % M;
                ans = (ans + t.second * x) % M;
                x = x * k % M;
            }
            printf(" %d", (int)ans);
        }
        puts("");
        puts("");
    }
    return 0;
}

