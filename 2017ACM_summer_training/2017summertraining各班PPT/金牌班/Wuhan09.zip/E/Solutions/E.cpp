/**********************************************************************
Author: Xay
Created Time:  2009-10-27 22:12:47
File Name: 
Description: 
**********************************************************************/
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <cstring>
using namespace std;

const int maxint = 0x7FFFFFFF;
const int maxn = 100000 + 100;

pair<int, int> a[maxn], rec[20];
char s[1000];
int n, q;

pair<int, int> find(int x) {
    if (a[x].first == -1) return make_pair(x, 0);
    pair<int, int> root = find(a[x].first);
    return a[x] = make_pair(root.first, root.second ^ a[x].second);
}
bool com(int x1, int x2, int x3) {
    pair<int, int> s1 = find(x1), s2 = find(x2);
    if (s1.first == s2.first) {
        return (s1.second^s2.second)==x3;
    }
    if (s1.first < s2.first) swap(s1, s2);
    a[s2.first] = make_pair(s1.first, s1.second^s2.second^x3);
    return true;
}
int main()
{
    int ca = 0;
    while (scanf("%d%d", &n, &q) == 2 && (n + q)) {
        printf("Case %d:\n", ++ca);
        bool ok = true;
        for (int i = 0; i <= n; ++i) {
            a[i] = make_pair(-1, 0);
        }
        int t = 0;
        while (q--) {
            if (!ok) {
                gets(s);
                continue;
            }
            scanf("%s", s);
            if (s[0] == 'I') {
                ++t;
                gets(s);
                int x1, x2, x3;
                if (sscanf(s, "%d%d%d", &x1, &x2, &x3) == 3) {
                    if (!com(x1, x2, x3)) ok = false;
                } else {
                    if (!com(x1, n, x2)) ok = false;
                }
                if (!ok) {
                    printf("The first %d facts are conflicting.\n", t);
                }
            } else {
                int k;
                scanf("%d", &k);
                bool flag = true;
                for (int i = 0; i < k; ++i) {
                    int x;
                    scanf("%d", &x);
                    rec[i] = find(x);
                }
                sort(rec, rec + k);
                int ans = 0;
                for (int i = 0; i < k; ++i) {
                    if (i > 0 && rec[i].first != rec[i - 1].first && !flag) {
                        break;
                    } else if (rec[i].first != n) {
                        flag = !flag;
                    }
                    ans ^= rec[i].second;
                }
                if (flag) printf("%d\n", ans);
                else printf("I don't know.\n");
            }
        }
        puts("");
    }
    return 0;
}

