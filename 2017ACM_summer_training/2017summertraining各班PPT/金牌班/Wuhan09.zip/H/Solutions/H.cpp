#include <cstdio>
#include <cstring>
#include <ctime>

const int       LIMIT_N = 100 + 10;
const int       LIMIT_K = 100 + 10;
const int       TYPE = 8;
const int       LIMIT_STAT = 1 << TYPE;

int         pn, n, k;
int         list    [LIMIT_N];
int         cnt     [LIMIT_N];
bool        app     [TYPE + 10];

int         after   [LIMIT_N];

void init()
{
    list[0] = -1;
    n = 0;

    memset(app, 0, sizeof(app));
    
    int x;
    while (pn --)
    {
        scanf("%d", &x); x -= 25;
        if (x == list[n]) cnt[n] ++;
        else {
            list[ ++ n ] = x;
            cnt[ n ] = 1;
        }
        app[ x ] = 1;
    }

    after[n + 1] = 0;
    for (int i = n; i >= 1; i --)
        after[n] = after[i + 1] + cnt[i];
}

int     opt [LIMIT_N][LIMIT_K][LIMIT_STAT];

inline int min(int a, int b) { return a < b ? a : b; }

void solve()
{
    memset(opt, 0x3f, sizeof(opt));

    opt[0][0][0] = 0;
    
    int     i, p, j, stat, nstat;
    int     ans = 12345678;

    for (i = 1; i <= n + 1; i ++)
    {
        for (p = 0; p <= k; p ++)
        {
            for (stat = 0; stat < (1<<TYPE); stat ++)
            {
                if (i <= n && ! (stat & (1<<list[i])) ) continue;
                if (i == n + 1) nstat = stat;
                else nstat = stat ^ (1<<list[i]);

                int rem = 0;
                for (j = i - 1; j >= 0 && p >= rem; j --)
                {
                    opt[i][p][stat] = min(opt[i][p][stat],
                                            min(opt[j][p-rem][stat], opt[j][p-rem][nstat]) + (i > n || list[i] == list[j] ? 0 : 1) );
                    rem += cnt[j];
                    if (list[j] == list[i]) break;
                }

                if (i == n + 1)
                {
                    int tmp = opt[i][p][stat];
                    for (int x = 0; x < TYPE; x ++)
                        if (app[x] && ! (stat & (1<<x)))
                            tmp ++;
                    ans = min(ans, tmp);
                }
            }
        }
    }

    printf("%d\n\n", ans);
}

int main()
{

    int case_no = 0;

    while (scanf("%d%d", &pn, &k) > 0 && pn)
    {
        printf("Case %d: ", ++ case_no);

        init();
        solve();
    }

    fprintf(stderr, "TWB run time : %.3lfs\n", clock() / (double)CLK_TCK);

    return 0;
}
